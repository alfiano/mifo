<?php

/**
 * Create Area For Header Banner
 */

function exposter_header_bg( $post ) {
    wp_nonce_field( 'header_bg_bg_submit', 'header_bg_bg_nonce' );
    $exposter_stored_meta = get_post_meta( $post->ID ); ?>
   
     <p> 
      <h4><?php esc_html_e('Select Header Style','exposter');?></h4> 
      <?php $trans_header = get_post_meta( $post->ID, 'trans_header', true ); 
  	  if($trans_header!=''){
  		  $header_style=$trans_header;
  	  }
  	  else{
  		   $header_style='Default Header';
  	  }
  	  ?>          
      <select name="trans_header">
       <option selected="selected" value="<?php echo esc_attr($header_style);?>"><?php echo  esc_attr($header_style);?></option>       
       <option value="Default Header"><?php  esc_html_e('Default Header','exposter');?></option>
       <option value="Transparent Header"><?php  esc_html_e('Transparent Header','exposter');?></option>             
      </select>
    </p>  


    <p> 
      <h4><?php esc_html_e('Select Logo Type','exposter');?></h4> 
      <?php $logo_header = get_post_meta( $post->ID, 'logo_style', true ); 
      if($logo_header !=''){
        $logo_type = $logo_header;
      }
      else{
         $logo_type = 'Dark Logo';
      }
      ?>          
      <select name="logo_style">
       <option selected="selected" value="<?php echo esc_attr($logo_type);?>"><?php echo  esc_attr($logo_type);?></option>       
       <option value="Dark Logo"><?php  esc_html_e('Dark Logo','exposter');?></option>
       <option value="Light Logo"><?php  esc_html_e('Light Logo','exposter');?></option>             
      </select>
    </p>
     
    <p>
      <h4><?php esc_html_e('Show Page Title','exposter');?></h4> 
       <?php $page_title = get_post_meta( $post->ID, 'page_title', true ); 
	     $page_style = 'Show';
		   if($page_title!=''){		  
			  $page_style=$page_title;
		  }	 
	  ?>          
      <select name="page_title">
        <option selected="selected" value = "<?php echo esc_attr( $page_style);?>"><?php echo esc_attr($page_style);?></option>
        <option value="Show"><?php esc_html_e('Show','exposter');?></option>
        <option value="Hide"><?php esc_html_e('Hide','exposter');?></option>
      </select>       
    </p>   
    
     <p>
      <h4><?php esc_html_e('Offcanvas Style','exposter');?></h4> 
       <?php $off_style= get_post_meta( $post->ID, 'off_style', true ); 
       $offstyle = 'default';
       if($off_style!=''){     
        $offstyle=$off_style;
      }  
      
    ?>          
      <select name="off_style">
        <option selected="selected" value = "<?php echo esc_attr( $offstyle);?>"><?php echo esc_attr($offstyle);?></option>
        <option value="Default"><?php esc_html_e('Default','exposter');?></option>
        <option value="Fullwidth"><?php esc_html_e('Fullwidth','exposter');?></option>
      </select>       
    </p>   

    <p> 
      <h4><?php esc_html_e('Show Breadcurmbs','exposter');?></h4> 
      <?php $page_bread = get_post_meta( $post->ID, 'page_bread', true ); 
       $bread_style = 'Show';
        if($page_bread!=''){      
          $bread_style = $page_bread;
        }  
    ?>
          
      <select name="page_bread">
         <option selected="selected" value = "<?php echo esc_attr( $bread_style);?>"><?php echo esc_attr($bread_style);?></option>
         <option value="Show"><?php  esc_html_e('Show','exposter');?></option>
         <option value="Hide"><?php  esc_html_e('Hide','exposter');?></option>
      </select>       
    </p> 

    <p> 
      <h4><?php esc_html_e('Select Footer Style','exposter');?></h4> 
      <?php $trans_footer = get_post_meta( $post->ID, 'trans_footer', true ); 
      if($trans_footer!=''){
        $footer_style=$trans_footer;
      }
      else{
         $footer_style='Footer Style 1';
      }
    ?>
          
      <select name="trans_footer">
         <option selected="selected" value="<?php echo esc_attr($footer_style);?>"><?php echo esc_attr($footer_style);?></option>
         <option value="Footer Style 1"><?php esc_html_e('Footer Style 1','exposter');?></option>
         <option value="Footer Style 2"><?php esc_html_e('Footer Style 2','exposter');?></option>
         <option value="Footer Style 3"><?php esc_html_e('Footer Style 3','exposter');?></option>
         <option value="Footer Style 4"><?php esc_html_e('Footer Style 4','exposter');?></option>             
      </select>       
    </p> 

<?php    

}

/**
 * Add Header background image metabox to the back end for pages
 */

function exposter_add_meta_boxes() {
    add_meta_box( 'case-study-bg', esc_html__('Header Settings', 'exposter'), 'exposter_header_bg', 'page', 'normal', 'high' );    

}
add_action( 'add_meta_boxes', 'exposter_add_meta_boxes' );

/**
 * Save background image metabox for header banner
 */

function save_header_bg_meta_box( $post_id ) {
    $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'header_bg_bg_nonce' ] ) && wp_verify_nonce( $_POST[ 'header_bg_bg_nonce' ], 'header_bg_bg_submit' ) ) ? 'true' : 'false';
    // Exits script depending on save status
    if ( $is_autosave || $is_revision || !$is_valid_nonce  ) {
        return;
    }

   //Save Value
  

   if( isset( $_POST[ 'trans_header' ] ) ) {
        update_post_meta( $post_id, 'trans_header', sanitize_text_field( $_POST['trans_header' ]));
    }

    if( isset( $_POST[ 'header_position' ] ) ) {
        update_post_meta( $post_id, 'header_position', sanitize_text_field( $_POST['header_position' ]));
    }

    

    if( isset( $_POST[ 'trans_footer' ] ) ) {
        update_post_meta( $post_id, 'trans_footer', sanitize_text_field( $_POST['trans_footer' ]));
    }
    
    
	 if( isset( $_POST[ 'page_title' ] ) ) {
        update_post_meta( $post_id, 'page_title', sanitize_text_field( $_POST[ 'page_title' ]));
    }
    if( isset( $_POST[ 'off_style' ] ) ) {
        update_post_meta( $post_id, 'off_style', sanitize_text_field( $_POST[ 'off_style' ]));
    }

    if( isset( $_POST[ 'page_bread' ] ) ) {
        update_post_meta( $post_id, 'page_bread', sanitize_text_field( $_POST[ 'page_bread' ]));
    }

     if( isset( $_POST[ 'logo_style' ] ) ) {
        update_post_meta( $post_id, 'logo_style', sanitize_text_field( $_POST[ 'logo_style' ]));
    }    
}
add_action( 'save_post', 'save_header_bg_meta_box' );


//content padding setting

function rs_content( $post ) {
    wp_nonce_field( 'rs_content_submit', 'rs_content_nonce' );
?>
    <p> 
      <h4><?php esc_html_e('Page Background','exposter');?></h4> 
      <?php $page_bg = get_post_meta( $post->ID, 'page_bg', true ); 
       $page_style = 'Light';
        if($page_bg != ''){      
          $page_style = $page_bg;
        }  
    ?>          
      <select name="page_bg">
         <option selected="selected" value = "<?php echo esc_attr( $page_style);?>"><?php echo esc_attr($page_style);?></option>
         <option value="Light"><?php  esc_html_e('Light','exposter');?></option>
         <option value="Dark"><?php  esc_html_e('Dark','exposter');?></option>
      </select>       
    </p>

    <?php $padding_top = get_post_meta( $post->ID, 'content-top', true ); 
    if($padding_top == ''):
      $padding_gap = '100px';
    else:
      $padding_gap = $padding_top;
    endif; ?>

    <p> 
      <h4><?php esc_html_e('Content Top Padding','exposter');?></h4>      
        <input type="text" size="35" name="content-top" class="content-top" value="<?php echo esc_attr($padding_gap); ?>" /><br />
        <span style="font-size: 12px; font-style: italic;"><?php esc_html_e('(example: 10px)','exposter');?></span>
    </p>
    <p>
    <?php $padding_bottom = get_post_meta( $post->ID, 'content-bottom', true ); ?>
    <?php if($padding_bottom == ''):
      $padding_gap_bottom = '100px';
    else:
      $padding_gap_bottom = $padding_bottom;
    endif; ?>
      <h4><?php esc_html_e('Content Bottom Padding','exposter');?></h4>      
        <input type="text" size="35" name="content-bottom" class="content-bottom" value="<?php echo esc_attr($padding_gap_bottom); ?>" /> <br />
        <span style="font-size: 12px; font-style: italic;"><?php esc_html_e('(example: 10px)','exposter');?></span>  
    </p>
<?php 
}

/**
 * Add Header background image metabox to the back end for pages
 */

function rs_add_page_boxes() {
    add_meta_box( 'page-setting', esc_html__('Page Settings', 'exposter'), 'rs_content', 'page', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'rs_add_page_boxes' );

/**
 * Save background image metabox for header banner
 */

function save_page_bg_meta_box( $post_id ) {
    $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'rs_content_nonce' ] ) && wp_verify_nonce( $_POST[ 'rs_content_nonce' ], 'rs_content_submit' ) ) ? 'true' : 'false';
   
    // Exits script depending on save status
    if ( $is_autosave || $is_revision || !$is_valid_nonce  ) {
        return;
    }
    
    //Save Value  
    
  if( isset( $_POST[ 'page_bg' ] ) ) {
        update_post_meta( $post_id, 'page_bg', sanitize_text_field( $_POST[ 'page_bg' ]));
    }  
  if( isset( $_POST[ 'content-top' ] ) ) {
        update_post_meta( $post_id, 'content-top', sanitize_text_field( $_POST[ 'content-top' ]));
    }
  if( isset( $_POST[ 'content-bottom' ] ) ) {
        update_post_meta( $post_id, 'content-bottom', sanitize_text_field( $_POST['content-bottom' ]));
    }   
    
}
add_action( 'save_post', 'save_page_bg_meta_box' );



//metabox for page & posts sidebar
/* Define the custom box */
 
add_action( 'add_meta_boxes', 'add_sidebar_metabox' );
add_action( 'save_post', 'save_sidebar_postdata' );
 
/* Adds a box to the side column on the Post and Page edit screens */
function add_sidebar_metabox()
{
    add_meta_box( 
        'custom_sidebar',
        esc_html__( 'Post Sidebar Setting', 'exposter' ),
        'custom_sidebar_callback',
        'post',
        'side'
    );
    add_meta_box( 
        'custom_sidebar',
        esc_html__( 'Page Sidebar Setting', 'exposter' ),
        'custom_sidebar_callback',
        'page',
        'side'
    );
}







/* Prints the box content */
function custom_sidebar_callback( $post ){
    global $wp_registered_sidebars;     
    $custom = get_post_custom($post->ID);     
    if(isset($custom['custom_sidebar']))
      $val = $custom['custom_sidebar'][0];
    else
      $val = "Sidebar"; 
    // Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'custom_sidebar_nonce' ); 
    // The actual fields for data entry
  	$left_check='';	
  	$right_check='';
  	$full_check='';
  	$lcalss='';
  	$rcalss='';
  	$fcalss='';
	
  	$page_layout = get_post_meta( $post->ID, 'layout', true );
  	if($page_layout == '2left'){
  		$left_check= 'checked="checked"';
  		$lcalss = 'active';
  	}
  	else if($page_layout == '2right'){
  		$right_check = 'checked="checked"';
  		$rcalss = 'active';		
  	}
  	
  	else{
  		$full_check = 'checked="checked"';
  		$fcalss = 'active';
  	}
	
	  $directory = get_template_directory_uri();	 
	  $output1 = '<div class="radio-select"><p><label for="myplugin_layout">'.esc_html__("Choose Layout", 'rswp' ).'</label></p>';
	  $output1 .='<input id="2left" type="radio" name="layout" value="2left" '.esc_attr($left_check).'><label for="2left" class="'.esc_attr($lcalss).'"><img src="'.esc_url($directory).'/assets/images/2cl.png" /></label>';
	  $output1 .='<input id="2right" type="radio" name="layout" value="2right" '.esc_attr($right_check).'><label for="2right" class="'.esc_attr($rcalss).'"><img src="'.esc_url($directory).'/assets/images/2cr.png" /></label>';
	  $output1 .='<input id="full" type="radio" name="layout" value="full" '.esc_attr($full_check).'><label for="full" class="full '.$fcalss.'"><img src="'.esc_url($directory).'/assets/images/1c.png" /></label></div>';
	  echo ($output1);
	
	  $output = '<p><label for="myplugin_new_field">'.esc_html__("Choose a sidebar to display", 'rswp' ).'</label></p>';    
    $output .= "<select name='custom_sidebar'>";
 
    // Add a default option
	  $themename = '';
    $output .= "<option";
    if($val == "default")
      $output .= " selected='selected'";
      $output .= " value='default'>".esc_html__('Select Sidebar','rswp')."</option>";
     
    // Fill the select element with all registered sidebars
    foreach($wp_registered_sidebars as $sidebar_id => $sidebar)
    {
        $output .= "<option";
        if($sidebar_id == $val)
        $output .= " selected='selected'";
        $output .= " value='".$sidebar_id."'>".$sidebar['name']."</option>";
    }     
    $output .= "</select>";       
    echo $output;
  }

/* When the post is saved, saves our custom data */
function save_sidebar_postdata( $post_id )
{
    // verify if this is an auto save routine. 
    // If it is our form has not been submitted, so we dont want to do anything
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
      return;
 
    // verify this came from our screen and with proper authorization,
    // because save_post can be triggered at other times
	
	  $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'custom_sidebar_nonce' ] ) && wp_verify_nonce( $_POST[ 'custom_sidebar_nonce' ], 'custom_sidebar_nonce' ) ) ? 'true' : 'false';
    // Exits script depending on save status
    if ( $is_autosave || $is_revision || !$is_valid_nonce  ) {
        return;
    }
 
    /*if ( !wp_verify_nonce( $_POST['custom_sidebar_nonce'], plugin_basename( __FILE__ ) ) )
      return;*/
 
    if ( !current_user_can( 'edit_page', $post_id ) )
        return;
 
    if( isset( $_POST[ 'custom_sidebar' ] ) ) {
        update_post_meta( $post_id, 'custom_sidebar', sanitize_text_field($_POST[ 'custom_sidebar' ]) );
    }
	
  	if( isset( $_POST[ 'layout' ] ) ) {
        update_post_meta( $post_id, 'layout', sanitize_text_field($_POST[ 'layout' ]) );
    }

}