<?php
/*
Element Description: Rs Gallery elements
*/
// Element Mapping

function vc_grassyClient_mapping() {
	 
	// Stop all if VC is not enabled
	if ( !defined( 'WPB_VC_VERSION' ) ) {
		return;
	}
	 
	// Map the block with vc_map()
	vc_map( 
		array(
			'name' => __('Rs Gallery Module', 'mifo'),
			'base' => 'vc_grassyClient',
			'description' => __('Rs Gallery Module', 'mifo'), 
			'category' => __('by RS Theme', 'mifo'),   
			'icon' => get_template_directory_uri().'/framework/assets/img/vc-icon.png',    
			'params' => array( 
			array(
				'type' => 'textfield',
				'holder' => 'h3',
				'class' => 'title-class',
				'heading' => __( 'Post Per Page', 'mifo' ),
				'param_name' => 'title',
				'value' => __( '4', 'mifo' ),				
				'admin_label' => false,
				'weight' => 0,
			),
			array(
				"type" => "dropdown",
				"heading" => __("Navigation", "exposter"),
				"param_name" => "navigation",
				"value" => array(							
					'Yes' => "",
					'No'  => "navigation-hidden",
				),
				'description' => __( 'You can show or hide navigation here.', 'mifo' ),
			),  
			 array(
				'type' => 'textfield',
				'heading' => __( 'Extra class name', 'mifo' ),
				'param_name' => 'el_class',
				'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'mifo' ),
			),
			array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'mifo' ),
			'param_name' => 'css',
			'group' => __( 'Design Options', 'mifo' ),
			),           
		 )
		)
	);                               
	
}
     
 add_action( 'vc_before_init', 'vc_grassyClient_mapping' );     
   // Element HTML
   function vc_grassyClient_html( $atts,$content ) {
         $attributes = array();
        // Params extraction
        extract(
            shortcode_atts(
                array(
					'title'      => '4',
					'navigation' => '',
					'el_class'   => '',					
					'css'        => ''            
                ), 
                $atts,'vc_grassyClient'
           )
        );
	
        //post per page
	    $per_page = $title;	  
	    //custom class added
		$wrapper_classes  = array($el_class) ;			
		$class_to_filter  = implode( ' ', array_filter( $wrapper_classes ) );		
		$css_class_custom = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class_to_filter, $atts );
		
	
		//extract css edit box
		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
		
        //******************//
        // query post
        //******************//
		
		$html='<div class="rs-partner '.$navigation.' '.$css_class.' '.$css_class_custom.'">           
					<div id="partner-carousels" class="gallery-slider">';       
		
						$best_wp = new wp_Query(array(
									'posts_per_page' =>$per_page,
									 'post_type'=>'gallery',
									'order' => 'DESC',
								));			   
						
							while($best_wp->have_posts()): $best_wp->the_post();
							   $post_title= get_the_title($best_wp->ID);					
							   $post_img_url = get_the_post_thumbnail_url($best_wp->ID,'full');	
							   $client_link = get_post_meta( get_the_ID(), 'client_link', true );	    		
						
		$html .='<div class="partner-item">
					<a class="image-popup" href="'.$post_img_url.'"><img src="'.$post_img_url.'" alt="'.$post_title.'"></a>
				</div>';
			endwhile; 
			wp_reset_query();
		$html .='</div>
	</div>';
 return $html; 
}
add_shortcode( 'vc_grassyClient', 'vc_grassyClient_html' );