<?php

	// Element Mapping
	 function vc_counter_mapping() {
         
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
    }         
    // Map the block with vc_map()
    vc_map(   
        array(
            'name' => __('Rs Counter', 'mifo'),
            'base' => 'vc_counter',
            'description' => __('Rs counter for project', 'mifo'), 
            'category' => __('by RS Theme', 'mifo'),   
            'icon' => get_template_directory_uri().'/framework/assets/img/vc-icon.png',            
            'params' => array(  
                      
                array(
                    'type' => 'textfield',
                    'holder' => 'h3',
                    'class' => 'title-class',
                    'heading' => __( 'Porject Title', 'mifo' ),
                    'param_name' => 'title',
                    'value' => __( '', 'mifo' ),
                    'description' => __( 'Project Title', 'mifo' ),
                    'admin_label' => false,
                    'weight' => 0,                   
                ), 
				
				  array(
                    'type' => 'textfield',
                    'holder' => 'h3',
                    'class' => 'project-class',
                    'heading' => __( 'Project Count', 'mifo' ),
                    'param_name' => 'project',
                    'value' => __( '', 'mifo' ),
                    'description' => __( 'Project counter (Example: 100 only number)', 'mifo' ),
                    'admin_label' => false,
                    'weight' => 0,
                    
                ), 
                  
                array(
					'type' => 'iconpicker',
					'heading' => __( 'Counter Icon', 'mifo' ),
					'param_name' => 'icon_fontawesome',
					'value' => '', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => true,
						// default true, display an "EMPTY" icon?
						'iconsPerPage' => 4000,
						// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
					),
				
					'description' => __( 'Select icon from library.', 'mifo' ),
				),
                array(
                    "type" => "dropdown",
                    "heading" => __("Select Icon Align", "asvc"),
                    "param_name" => "align",
                    "value" => array(
                        __( 'Center', 'mifo' ) => '',
                        __( 'Left', 'mifo' )   => 'left',
                        __( 'Right', 'mifo' )  => 'right',
                    ),
                    "std" => 'style1',
                    "admin_label" => true,
                    "description" => __("", "asvc")
                ),
				 array(
						'type' => 'textfield',
						'heading' => __( 'Extra class name', 'mifo' ),
						'param_name' => 'el_class',
						'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'mifo' 										                            ),
					),        
                     
           	)
        )
    );                                
        
}
add_action( 'vc_before_init', 'vc_counter_mapping' ); 
// Element HTML
function vc_counter_html( $atts ) {     
    // Params extraction
    extract(
        shortcode_atts(
            array(
                'title'            => 'Counter Title',
                'project'          => '',
                'align'            => '',
                'icon_fontawesome' =>'',
                'el_class'         =>'',
            ), 
            $atts,'vc_counter'
        )
    );	
     //custom class added
	$wrapper_classes = array($el_class) ;			
	$class_to_filter = implode( ' ', array_filter( $wrapper_classes ) );		
	$css_class_custom = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class_to_filter, $atts );

    $count_icon = ($icon_fontawesome !== '') ? '<div class="count-icon"><i class="'.$icon_fontawesome.'"></i></div>' : '';

    $html = '
	<div class="counter-top-area '.$align.'">
    <div class="rs-counter-list">
		'.$count_icon.'
        <div class="count-text"><h2 class="rs-counter">' . $project. '</h2>         
        <h3>'.$title.'</h3></div>
    </div></div>';
     
    return $html;
     
}
add_shortcode( 'vc_counter', 'vc_counter_html' );