<?php
/*
Element Description: Rs Slider
*/
     
// Element Mapping
function vc_slider_mapping() {     
    // Stop all if VC is not enabled
    if ( !defined( 'WPB_VC_VERSION' ) ) {
        return;
    }     
    // Map the block with vc_map()
    vc_map( 
        array(
            'name' => __('Rs Slider', 'rs-option'),
            'base' => 'vc_slider',
            'description' => __('Rs Slider Addon', 'rs-option'), 
            'category' => __('by RS Theme', 'rs-option'),   
            'icon' => get_template_directory_uri().'/framework/assets/img/vc-icon.png',           
            'params' => array(
            	array(
            		"type" => "textfield",
            		"heading" => __("Slide Per Page", "rs-option"),
            		"param_name" => "slider_per",
            		'value' =>"6",
            		'description' => __( 'You can write how many slide show. ex(2)', 'rs-option' ),					
            	),
                array(
					"type" => "dropdown",
					"heading" => __("Show title", "rs-option"),
					"param_name" => "title",
					"value" => array(
						'Yes' => "Yes", 
						'No' => "No",					
					),
				),
				array(
					"type" => "dropdown",
					"heading" => __("Show Short Description", 'rs-option'),
					"param_name" => "description",
					"value" => array(
						'Yes' => "Yes", 
						'No' => "No",										
					),
				),
				array(
					"type" => "dropdown",
					"heading" => __("Background Position", "rs-option"),
					"param_name" => "background_position",
					"value" => array(
						'Left Top'      => 'left top',
						'Left Center'   => 'left center',
						'Left Bottom'   => 'left bottom',
						'Right Top'     => 'right top',
						'Right Center'  => 'right center',
						'Right Bottom'  => 'right bottom',
						'Center Top'    => 'center top',
						'Center Center' => 'center center',
						'Center Bottom' => 'center bottom'
					),
					'description' => __( 'Set background image position here', 'rs-option' )
				),
				array(
					'type' => 'css_editor',
					'heading' => __( 'CSS box', 'rs-option' ),
					'param_name' => 'css',
					'group' => __( 'Design Options', 'rs-option' ),
				),
            ),		
				
        )
    );                                   
}
 
add_action( 'vc_before_init', 'vc_slider_mapping' );
     
// Element HTML
function vc_slider_html( $atts,$content ) {
    $attributes = array();
    // Params extraction
    extract(
        shortcode_atts(
            array(
				'title'               => '',
				'description'         => '',
				'slider_per'          => '6',
				'background_position' => 'bottom right',
				'css'                 => ''
            ), 
            $atts,'vc_slider'
       )
    );

	//extract css edit box
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );

	$html='<div class="rs-slider">
		<div class="rs-slider-carousel">';		
		$post_title_show='';
		$description_team='';
			
        // Query Post
		$best_wp = new wp_Query(array(
			'post_type' => 'sliders',
			'posts_per_page' =>$slider_per,
		));
		
		while($best_wp->have_posts()): $best_wp->the_post();
		   $post_title = get_the_title($best_wp->ID);
		   $post_content = get_the_content();
		   
		    if($title != 'No') {
		   		$post_title_show = get_the_title($best_wp->ID);
			}		
					
		    $post_img_url = get_the_post_thumbnail_url($best_wp->ID,'full');
		    $post_url = get_post_permalink($best_wp->ID);

		    $btn1_text = get_post_meta( get_the_ID(), 'btn1_text', true );
		    $btn2_text = get_post_meta( get_the_ID(), 'btn2_text', true );

		    $btn1_url = get_post_meta( get_the_ID(), 'btn1_url', true );
		    $btn2_url = get_post_meta( get_the_ID(), 'btn2_url', true );

		    $slide_align = get_post_meta( get_the_ID(), 'slide_align', true );
		    $extra_class = get_post_meta( get_the_ID(), 'extra_class', true );

			$html .='<div class="slider-item '.$extra_class.'" style="background-image: url('.$post_img_url.');background-position:'.$background_position.';">					    
					    <div class="slide-content '.$slide_align.' '.$css_class.'">
					        <h2 class="slide-title">'.$post_title_show.'</h2>

					        <div class="slide-description">
					            <p>'.$post_content.'</p>
					        </div>';

					        if ($btn1_text || $btn2_text || $btn1_url || $btn2_url) {
					    	    $html .='<div class="slider-button">
			    					        <ul>';

			    					        	if ($btn1_text || $btn1_url) {
			    					            	$html .='<li><a href="'.$btn1_url.'" title="'.$btn1_text.'" class="border readon smoothPortfolio">'.$btn1_text.'</a></li>';
			    					        	}

			    					        	if ($btn2_text || $btn2_url) {
			    					            	$html .='<li><a href="'.$btn2_url.'" title="'.$btn2_text.'" class="readon border">'.$btn2_text.'</a></li>';
			    					            }

			    					        $html .='</ul>
			    					    </div>';
			        		}

					    $html .='</div>
					</div>';
		
		endwhile; 
       	wp_reset_query();
		$html .='</div>
	</div>';
	return $html;
}
add_shortcode( 'vc_slider', 'vc_slider_html' );